from django.db import models
from django.forms import CharField

# Create your models here.


class HomeModel(models.Model):
    name=CharField()