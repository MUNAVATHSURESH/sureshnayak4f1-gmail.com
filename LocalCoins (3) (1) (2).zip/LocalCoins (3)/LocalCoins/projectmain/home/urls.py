from gateway import views
from django.urls import path

urlpatterns = [

    path('HomeTRY/', views.Home),
]
