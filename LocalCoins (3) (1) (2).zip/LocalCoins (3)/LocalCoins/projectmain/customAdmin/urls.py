from django.urls import path
from customAdmin import views

urlpatterns = [
    path('h/', views.getDashboard, name="adminHome"),
    path('u/', views.getAllUsers, name="adminUsers"),
    path('au/', views.getActiveUsers, name="adminActiveUsers"),
    path('bu/', views.getBannedUsers, name="adminBannedUsers"),
    path('eu/', views.getEmailUnverified, name="adminEmailUnverified"),
    path('su/', views.getSmsUnverified, name="adminSmsUnverified"),
    path('cc/', views.getAllCCurrs,name="adminSearchCC"),
    path('aCC/', views.saveCCurr, name="adminSaveCC"),
    path('uCC/<slug:id>', views.updateCCurr, name ="adminUpdateCC"),
    path('fc/', views.getAllFcurrs, name="adminSearchFC"),
    path('aFC/', views.saveFcurr, name="adminSaveFC"),
    # path('uFC/<slug:id>', views.updateFcurr, name="adminUpdateFC"),
    path('fg/', views.getAllgateways, name="adminSearchFg"),
    path('aFG/', views.getAddgateways, name="adminAddFg"),
    path('pw/', views.getShowPaymentWindow, name="adminShowPaymentWindow"),
    path('aPW/', views.getAddPaymentWindow, name="adminAddPaymentWindow"),
    path('advt/', views.showAllAdvt, name="adminAdvertisement" ),
    path('tr/', views.showAllTradeRequest, name="adminTradeRequest" ),
    path('a/', views.saveUsers, name="saveU"),
    path('u/<slug:id>', views.updateUsers, name="updateU"),
    path('s/', views.getAllUsers, name="searchU"),
    path('as/', views.getShowApiPages, name="adminApiSetting"),
    path('gs/', views.getShowGenralSetting, name="adminGenralSetting"),
]
