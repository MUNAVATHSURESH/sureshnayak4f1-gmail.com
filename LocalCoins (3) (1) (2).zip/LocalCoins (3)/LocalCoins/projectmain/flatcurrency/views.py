from datetime import datetime
from django.shortcuts import render
from django.db.models import Q
from flatcurrency.form import FlatCurrencyForm

from flatcurrency.models import FlatCurrency
from user.models import User
# Create your views here.



def getAllFcurrs(request):
    flatCurrs = FlatCurrency.objects.all()
    if request.method == "POST":
        searchName = request.POST.get('search')
        flatCurrs = FlatCurrency.objects.filter(
            Q(fcName__icontains=searchName) | Q(fcCode__icontains=searchName))
        return render(request, 'flatCurrency/flatcurrency.html', {'fcList': flatCurrs})
    return render(request, 'flatCurrency/flatcurrency.html', {'fcList': flatCurrs})



def saveFcurr(request):
    if request.method == "POST":
        form = FlatCurrencyForm(request.POST, request.FILES)
        if form.is_valid():
            fcSaved = form.save(commit=False)
            fcSaved.fcCreatedBy = User.objects.get(uUserName="SYSTEM")
            fcSaved.fcCreatedDate = datetime.now()
            fcSaved.fcStatus = 1
            fcSaved.save()
    form = FlatCurrencyForm()
    return render(request, 'flatcurrency/flatcurrency.html', {'form': form})


def updateFcurr(request,id):
    fc = FlatCurrency.objects.get(pk=id)
    flatCurrs = FlatCurrency.objects.all()
    if request.method == "POST":
        form = FlatCurrencyForm(request.POST, request.FILES, instance=fc)
        if form.is_valid():
            fcSaved = form.save(commit=False)
            fcSaved.fcUpdatedBy = User.objects.get(uUserName="SYSTEM")
            fcSaved.fcUpdatedDate = datetime.now()
            fcSaved.fcStatus = 1
            fcSaved.save()
    form = FlatCurrencyForm()
    return render(request, 'flatcurrency/flatcurrency.html', {'form': form,'fc':fc,'fcList': flatCurrs})