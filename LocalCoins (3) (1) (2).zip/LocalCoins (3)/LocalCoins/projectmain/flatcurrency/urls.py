from flatcurrency import views
from django.urls import path

urlpatterns = [
    path('', views.getAllFcurrs, name="searchFC"),
    path('a/', views.saveFcurr, name="saveFC"),
    path('u/<slug:id>', views.updateFcurr, name="updateFC"),
]
