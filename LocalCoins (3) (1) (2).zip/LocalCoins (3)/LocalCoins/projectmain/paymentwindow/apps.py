from django.apps import AppConfig


class PaymentwindowConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'paymentwindow'
