from django.contrib import admin

from gateway.models import Gateway

# Register your models here.


class GatewayAdmin(admin.ModelAdmin):
    list_display = [
        'gName',
        'gSlug',
        'gStatus',
        'gCreatedBy',
        'gCreatedDate',
        'gUpdatedBy',
        'gUpdatedDate',
    ]


admin.site.register(Gateway, GatewayAdmin)



