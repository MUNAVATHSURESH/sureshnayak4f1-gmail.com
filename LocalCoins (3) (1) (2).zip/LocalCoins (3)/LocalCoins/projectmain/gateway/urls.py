from gateway import views
from django.urls import path

urlpatterns = [
    
    path('gatewayurl/', views.gatewayPages),
]
