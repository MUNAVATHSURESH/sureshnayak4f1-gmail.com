from datetime import datetime
from django.db import models
from user.models import User
# Create your models here.


class CryptoCurrency(models.Model):
    ccName = models.CharField(max_length=30, primary_key=True)
    ccImg = models.ImageField(null=True, upload_to="media/")
    ccCode = models.CharField(max_length=30, null=False)
    ccSymbol = models.CharField(max_length=100, null=True)
    ccRate = models.FloatField(null=False)
    ccDepositeFixedChrg = models.FloatField(null=False)
    ccDepositePerChrg = models.FloatField(null=False)
    ccWithdrawFixedChrg = models.FloatField(null=False)
    ccWithdrawPerChrg = models.FloatField(null=False)
    ccStatus = models.IntegerField(default=1, null=False)
    ccCreatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sCreatedBy', null=False)
    ccCreatedDate = models.DateTimeField(default=datetime.now, null=False)
    ccUpdatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sUpdatedBy', null=True)
    ccUpdatedDate = models.DateTimeField(default=datetime.now, null=True)
