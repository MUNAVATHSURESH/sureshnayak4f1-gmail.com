
from django import forms
from cryptocurrency.models import CryptoCurrency


class CryptoCurrencyForm(forms.ModelForm):
    #fields with validations
    class Meta:
        model = CryptoCurrency
        exclude = ('ccCreatedBy', 'ccCreatedDate',
                   'ccUpdatedBy', 'ccUpdatedDate','ccStatus')
