# Register your models here.
from django.contrib import admin
from cryptocurrency.models import CryptoCurrency
# Register your models here.
class CryptoCurrencyAdmin(admin.ModelAdmin): 
    list_display=[
        'ccName',
        'ccImg',
        'ccCode',
        'ccSymbol',
        'ccRate',
        'ccDepositeFixedChrg',
        'ccDepositePerChrg',
        'ccWithdrawFixedChrg',
        'ccWithdrawPerChrg',
        'ccStatus',
        'ccCreatedBy',
        'ccCreatedDate',
        'ccUpdatedBy',
        'ccUpdatedDate'

    ] 
admin.site.register(CryptoCurrency,CryptoCurrencyAdmin)