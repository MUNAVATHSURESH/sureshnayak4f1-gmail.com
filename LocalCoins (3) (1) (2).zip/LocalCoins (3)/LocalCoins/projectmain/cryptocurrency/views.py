from datetime import datetime
from django.shortcuts import render

from django.db.models import Q
from cryptocurrency.form import CryptoCurrencyForm
from cryptocurrency.models import CryptoCurrency
from user.models import User

# Create your views here.


def getAllCCurrs(request):
    cryptoCurrs = CryptoCurrency.objects.all();
    if request.method == "POST":
        searchName = request.POST.get('search')
        cryptoCurrs = CryptoCurrency.objects.filter(
            Q(ccName__icontains=searchName) | Q(ccCode__icontains=searchName))
        return render(request, 'admin/cryptocurrency.html', {'ccList': cryptoCurrs})
    return render(request, 'admin/cryptocurrency.html', {'ccList': cryptoCurrs})


def saveCCurr(request):
    if request.method == "POST":
        form = CryptoCurrencyForm(request.POST, request.FILES)
        if form.is_valid():
            ccSaved = form.save(commit=False)
            ccSaved.ccCreatedBy = User.objects.get(uUserName="SYSTEM")
            ccSaved.ccCreatedDate = datetime.now()
            ccSaved.ccStatus = 1
            ccSaved.save()
    form = CryptoCurrencyForm()
    return render(request, 'cryptocurrency/addCC.html', {'form': form})


def updateCCurr(request,id):
    cc = CryptoCurrency.objects.get(pk=id)
    if request.method == "POST":
        form = CryptoCurrencyForm(request.POST, request.FILES, instance=cc)       
        if form.is_valid():
            ccSaved = form.save(commit=False)
            ccSaved.ccUpdatedBy = User.objects.get(uUserName="SYSTEM")
            ccSaved.ccUpdatedDate = datetime.now()
            ccSaved.ccStatus = 1
            ccSaved.save()
            cryptoCurrs = CryptoCurrency.objects.all()
            return render(request, 'cryptocurrency/cryptocurrency.html', {'ccList': cryptoCurrs})
    form = CryptoCurrencyForm()
    return render(request, 'cryptocurrency/updateCC.html', {'form': form,'cc':cc})
