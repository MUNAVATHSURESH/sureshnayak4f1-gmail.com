from django.db import models

from cryptocurrency.models import CryptoCurrency

# Create your models here.

class GatewayCurr(models.Model):
    gcName = models.CharField(max_length=30, primary_key=True)
    gcCCurency = models.ForeignKey(
        CryptoCurrency, on_delete=models.CASCADE, related_name='%(class)sCryptoCurrency', null=False)