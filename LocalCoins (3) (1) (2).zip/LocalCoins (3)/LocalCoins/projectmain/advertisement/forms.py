

from django import forms

from advertisement.models import Advertisement


class AdvertisementForm(forms.ModelForm):
    #fields with validations
    class Meta:
        model = Advertisement
        exclude = ('aCreatedBy', 'aCreatedDate',
                   'aUpdatedBy', 'aUpdatedDate','aStatus')